#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(){
    pid_t pid = fork();

    if (pid == 0)
    {
        printf("baby is sleep");
        execlp("sleep","sleep","3", NULL);
        perror("error in baby");
        exit(EXIT_FAILURE);
    }
    else if (pid > 0)
    {
        printf("pid%d create ppid %d\n", getpid(),pid);

        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status))
        {
            printf("baby end with status %d\n" , WEXITSTATUS(status));
        }
        else{
            perror("error when created\n");
            exit(EXIT_FAILURE);
        }   
    }
    return 0;
}