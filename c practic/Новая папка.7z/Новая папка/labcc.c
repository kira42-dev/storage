#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
    pid_t pid1, pid2;
    int status;

    pid1 = fork();

    if (pid1 == 0)
    {
        printf("(PID = %d)", getpid());
        execlp("ls","ls","-l", NULL);
    }
    else if (pid1 > 0)
    {
        printf("(PID = %d)", getpid() , pid1 );
        
    waitpid(pid1, &status , 0)
    }
    return 0;
}