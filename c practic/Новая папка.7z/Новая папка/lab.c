#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(){
    printf("my pididi \n", getpid());
    printf("change myself to ls la\n");
    execlp("ls","ls","-la", NULL);
    return 0;
}